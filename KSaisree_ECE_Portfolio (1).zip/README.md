# KSaisree ECE Portfolio — GitHub Pages

## Files included
- `index.html` — portfolio content and mobile navigation
- `style.css` — responsive modern dark-blue design

## Before you publish
1. Replace `[YOUR COLLEGE NAME]`, `[MONTH YEAR]`, `[YOUR_EMAIL_ADDRESS]`, `YOUR_EMAIL_ADDRESS`, `YOUR_LINKEDIN_PROFILE_URL`, `[YOUR CITY, STATE]`, and other bracketed placeholders.
2. Edit the NARL and Tata Electronics descriptions so they accurately reflect your actual dates, role, and work.
3. Keep only the skills and certificates you can verify.
4. Add your photo later: create an `assets` folder, upload a photo named `profile.jpg`, then replace the photo placeholder in `index.html` with:
   `<img class="profile-photo" src="assets/profile.jpg" alt="Portrait of KSaisree">`
5. The resume button currently jumps to a note saying the resume is coming soon. When ready, upload your PDF as `resume.pdf` and replace the resume button with:
   `<a class="button button-primary" href="resume.pdf" target="_blank" rel="noopener">View my resume ↗</a>`

## Publish from Android
1. In Chrome, sign in to GitHub at https://github.com/.
2. Create a **public** repository named exactly `KSaisree-ECE.github.io`.
3. Upload `index.html` and `style.css` directly into the repository root.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Choose branch `main` and folder `/(root)`, then tap **Save**.
7. Wait for the Pages deployment to complete. Your site address should be:
   https://ksaisree-ece.github.io/

If the mobile interface does not show file upload options, open Chrome's three-dot menu and enable **Desktop site**.

## Privacy
Do not publish your Aadhaar number, personal home address, passwords, or private documents. Use a professional email address and only share information you are comfortable making public.
